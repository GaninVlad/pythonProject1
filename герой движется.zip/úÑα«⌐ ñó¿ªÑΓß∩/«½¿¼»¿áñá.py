import os
import sys
import pygame
pygame.init()
size = width, height = 500, 500
screen = pygame.display.set_mode(size)


def load_image(name, colorkey=None):
    fullname = os.path.join('../data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image

def main():
    all_sprites = pygame.sprite.Group()
    sprite = pygame.sprite.Sprite()
    sprite.image = load_image("creature.png")
    sprite.rect = sprite.image.get_rect()
    all_sprites.add(sprite)
    size = 300, 300
    screen = pygame.display.set_mode(size)
    running = True
    shag = 10
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            screen.fill((pygame.Color('White')))
            key = pygame.key.get_pressed()
            if key[pygame.K_UP]:
                sprite.rect.top -= shag
            elif key[pygame.K_DOWN]:
                sprite.rect.top += shag
            elif key[pygame.K_LEFT]:
                sprite.rect.left -= shag
            elif key[pygame.K_RIGHT]:
                sprite.rect.left += shag
            all_sprites.draw(screen)
        pygame.display.flip()
    pygame.quit()

if __name__ == '__main__':
    sys.exit(main())